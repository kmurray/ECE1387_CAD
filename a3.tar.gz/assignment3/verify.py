#!/usr/bin/python

#This script verifies that kpartition generates the same results if run with
# pruning (lower bounding) and by brute force
import subprocess
import re
import sys

test_ccts = ['test1', 'test2', 'test3', 'cct1', 'test4']

cut_count_regex = re.compile(r"^Final solution cut count: (?P<cut_count>\d+)")

default_opts = ['-t', '-n', '-v0']

def parse_output(output):
    for line in output.split('\n'):
        match = cut_count_regex.match(line)
        if match:
            return int(match.group('cut_count'))

    print "\nError: could find cut count when parsing result!"
    sys.exit(1)
        

if __name__ == '__main__':

    #Build kpartition
    print "Compiling ..."
    cmd = ['make', '-j4']
    try: subprocess.check_call(cmd)
    except subprocess.CalledProcessError:
        print "Error: make failed!"

    print
    print "Starting Testing:"
    for cct in test_ccts:
        
        print "Testing {cct}...".format(cct=cct),
        sys.stdout.flush()

        #First get the pruned result
        cmd = ['kpartition',
               '-c', cct]
        cmd += default_opts
        
        output = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()[0]

        pruned_cut_count = parse_output(output)

        #Then get the brute force results

        cmd = ['kpartition',
               '-c', cct,
               '-b']
        cmd += default_opts
        
        output = subprocess.Popen(cmd, stdout=subprocess.PIPE).communicate()[0]

        bf_cut_count = parse_output(output)

        if pruned_cut_count == bf_cut_count:
            print "OK"
        else:
            print "Failed!"
            print "\tBnB: {pruned}, BF: {bf}".format(pruned = pruned_cut_count, bf = bf_cut_count)
