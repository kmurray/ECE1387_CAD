//================================================================================================
// INCLUDES 
//================================================================================================
#include <math.h>
#include <assert.h>
#include <data_structs.h>
#include <util.h>
#include <branch_and_bound.h>
#include <initial_solution.h>
#include <bound.h>
#include <verify.h>
#include <draw.h>


//================================================================================================
// INTERNAL FUNCTION DECLARTAIONS 
//================================================================================================
t_bbnode* solve_bnb_subproblem(t_bbnode* root, t_bbnode* prev_best, bool use_upper_bound);
int create_subproblems(t_bbnode* root);
t_bbnode* update_best(t_bbnode* best, int subproblem_value, t_bbnode* subproblem);
void add_subproblems_to_queue(t_bbnode* parent, t_bbnode_queue* queue);
t_bbnode* create_subproblem(t_bbnode* parent, t_side side, int new_index);
t_bbnode* create_bnb_tree_root();

void prune_subproblem(t_bbnode* subproblem, t_status prune_reason);
bool prune_subproblem_balance(t_bbnode* subproblem);
bool prune_subproblem_bound(t_bbnode* subproblem);

int create_subproblems_binary(t_bbnode* node);
t_bbnode* create_subproblem_binary(t_bbnode* parent, t_side side);
//================================================================================================
// INTERNAL FUCTION IMPLIMENTATIONS
//================================================================================================

//Solves the branch and bound partitioning problem
t_bbnode* solve_bnb(t_bbnode* initial_soln){
    t_bbnode* root = create_bnb_tree_root();

    g_search_root = root;
    g_best_soln = evaluate_solution(initial_soln);
    if(g_args->force_initial != -1) {
        g_best_soln = g_args->force_initial;
    }
    printf("\nStarting Branch and Bound\n");
    printf("  Initial Solution: %d\n", g_best_soln);

    if(!g_args->no_disp && g_args->interactive_graphics) { 
        start_interactive_graphics();
    }
    t_bbnode* solution = solve_bnb_subproblem(g_search_root, initial_soln, true);

    return solution;

}

t_bbnode* solve_bnb_subproblem(t_bbnode* root, t_bbnode* initial_soln, bool use_upper_bound) {
    t_bbnode* best = initial_soln;

    t_bbnode_queue bbnode_queue; 

    t_bbnode_pair root_pair (0, root);
    bbnode_queue.push(root_pair);


    while(!bbnode_queue.empty()) {
        t_bbnode* subproblem = bbnode_queue.top().second;
        bbnode_queue.pop();


        //Stats counter
        g_stats.num_nodes_explored++;


        if(fmod(g_stats.num_nodes_explored, NODES_PER_PROGRESS_UPDATE) == 0.) {
            printf("  Explored %.2e nodes\n", g_stats.num_nodes_explored);
            if(g_args->interactive_graphics) {
                draw_screen();
            }
        }

        //Evaluate this subproblem


        //Prune based on balance first, to avoid issues in bound calculation
        if(prune_subproblem_balance(subproblem)) continue;

        DEBUG_PRINT(EXTRA_INFO, "    Subproblem: '%s'\n", dump_solution_str(subproblem).c_str());
        //dump_solution(subproblem);
        
        //Find an upper bound for this subproblem
        //  If it is better than best, then we can update best early
        subproblem->UB = find_subproblem_upper_bound(subproblem);
        if(subproblem->UB < g_best_soln) {
            if(subproblem->UB < g_best_UB) {
                //Should improve pruning
                printf("\t\tFound new subproblem upper bound (%d) better the previous best (%d)\n", subproblem->UB, max(g_best_soln, g_best_UB));
                if(!g_args->brute_force) {
                    g_best_UB = subproblem->UB;
                }
            }
        }

        //Find a lower bound
        subproblem->LB = find_subproblem_lower_bound(subproblem);
        subproblem->status = NORMAL;

        check_bound_consistensy(subproblem);
        //Prune based on bounds
        if(prune_subproblem_bound(subproblem)) continue;


        //Generate sub-problems
        if(g_args->tree_type == BINARY) {
            create_subproblems_binary(subproblem);
        } else {
            create_subproblems(subproblem);

        }
        add_subproblems_to_queue(subproblem, &bbnode_queue);

        //Compare against the current best solution
        if(subproblem->is_full_solution) {
            //No new subproblems => a full solution (leaf node)
            int subproblem_value = evaluate_partial_solution_fixed_only(subproblem);

            //Sanity check on bounds, this really only useful if running
            // in brute force mode
            assert(subproblem->LB <= subproblem_value);
            assert(subproblem->UB >= subproblem_value);
            int gap = subproblem_value - subproblem->LB;
            if(gap != 0) {
                printf("\tLB and Soln Gap: %d\n", subproblem_value - subproblem->LB);
            }
            //assert(subproblem_UB >= subproblem_value);

            if(g_best_soln > subproblem_value) {
                //Intermediate is better
                best = update_best(best, subproblem_value, subproblem);

            }
            //start_interactive_graphics();
        }
    }
   
    return best;
}

t_bbnode* update_best(t_bbnode* best, int subproblem_value, t_bbnode* subproblem) {
    g_best_soln = subproblem_value;
    printf("\tFound new best: %d\n", g_best_soln);
    //draw_screen();
    //start_interactive_graphics();
    
    //Save old best
    t_bbnode* old_best = best;

    //New best
    best = subproblem;

    //Mark them appropriately
    old_best->status = OLD_BEST;
    best->status = BEST;

    return best;
}

void add_subproblems_to_queue(t_bbnode* parent, t_bbnode_queue* queue) {
    for(t_bbnode_map::iterator bbnode_iter = parent->children.begin(); bbnode_iter != parent->children.end(); bbnode_iter++) {
        t_bbnode* child = bbnode_iter->second;
        t_bbnode_pair child_pair (0, child);
        queue->push(child_pair);
    }
}


t_bbnode* finalize_solution(t_bbnode* subproblem) {
    //assert(subproblem->left_blocks.size() == subproblem->free_blocks.size());
    assert(subproblem->left_blocks.size() == g_blocklist.size() / 2 ||
           subproblem->right_blocks.size() == g_blocklist.size() / 2);
    
    t_block_map* side_to_copy_into;
    if(subproblem->right_blocks.size() == g_blocklist.size()/2) {
        assert(g_blocklist.size()/2 - subproblem->left_blocks.size() == subproblem->free_blocks.size());
        side_to_copy_into = &subproblem->left_blocks;
    } else {
        assert(g_blocklist.size()/2 - subproblem->right_blocks.size() == subproblem->free_blocks.size());
        side_to_copy_into = &subproblem->right_blocks;
    }

    //Move all the remaining blocks from the freelist to the correct side
    if(side_to_copy_into->size() == 0) {
        *side_to_copy_into = subproblem->free_blocks;
    } else {
        for(t_block_map::iterator free_blk_iter = subproblem->free_blocks.begin(); free_blk_iter != subproblem->free_blocks.end(); free_blk_iter++) {
            side_to_copy_into->insert(t_block_pair(free_blk_iter->first, free_blk_iter->second));
        }
    }
    subproblem->free_blocks.erase(subproblem->free_blocks.begin(), subproblem->free_blocks.end());

    //Mark as full solution
    subproblem->is_full_solution = true;

    return subproblem;

}

void prune_subproblem(t_bbnode* subproblem, t_status prune_reason) {
        assert(prune_reason == PRUNED_BOUND || prune_reason == PRUNED_BALANCE);

        subproblem->status = prune_reason;
        
        g_stats.num_nodes_pruned++;
}

bool prune_subproblem_balance(t_bbnode* subproblem) {
    bool prune = false;
    if (subproblem->left_blocks.size() > g_blocklist.size()/2 || 
               subproblem->right_blocks.size() > g_blocklist.size()/2) {
        //Prune based on balance constraints
        prune = true;
        t_status prune_reason = PRUNED_BALANCE;

        prune_subproblem(subproblem, prune_reason);

    }
    return prune;
}


bool prune_subproblem_bound(t_bbnode* subproblem) {
    bool prune = false;
    t_status prune_reason = NORMAL;
    if(g_args->brute_force) {
        //Don't prune if doing brute force
        prune = false;
    } else if(subproblem->LB > min(g_best_soln, g_best_UB)) {

        if(subproblem->UB == g_best_UB && g_best_UB > g_best_soln) {
            //If we have an UB equal to the best UB
            //  and we still haven't found the matching
            //  solution => don't prune
            prune = false;
        } else {
            //If better than the best solution prune
            prune = true; 
            prune_reason = PRUNED_BOUND;
        }
    }

    if(prune) {
        //printf("\tPruned: '%s'\n", dump_solution_str(subproblem).c_str());
        prune_subproblem(subproblem, prune_reason);

    }
    return prune;
}

/*
 *  Creates a set of sub-problems for the specified node
 */
int create_subproblems_binary(t_bbnode* node) {
    int num_new_subproblems = 2;

    t_bbnode* subproblem_left = create_subproblem_binary(node, LEFT);
    if(subproblem_left != NULL) {
        node->children[0] = subproblem_left;
    }

    t_bbnode* subproblem_right = create_subproblem_binary(node, RIGHT);
    if(subproblem_right != NULL) {
        node->children[1] = subproblem_right;
    }

    return num_new_subproblems;
}

/*
 * Creates a new subproblm based on the parent problem, and the next
 *   index to insert on the left side
 */
t_bbnode* create_subproblem_binary(t_bbnode* parent, t_side side) {
    if (parent->free_blocks.begin() != parent->free_blocks.end()) {
        //Not a leaf

        //There is room to add another sub-problem without upsetting the balance restirctions
        t_bbnode* subproblem = duplicate_subproblem(parent);

        subproblem->parent = parent;
        subproblem->level = parent->level + 1;
        subproblem->status = UNBOUNDED;
        subproblem->LB = SMALL_BOUND;
        subproblem->UB = BIG_BOUND;

        t_block_map::iterator blk_iter = parent->free_blocks.begin();
        assert(blk_iter != parent->free_blocks.end());

        add_block_from_freelist(blk_iter->first, side, subproblem);
        
        if(subproblem->free_blocks.size() == 0) {
            subproblem->is_full_solution = true;
        } else {
            subproblem->is_full_solution = false;
        }

        verify_subproblem(subproblem);

        return subproblem;
    } else {
        return NULL;
    }
}

/*
 *  Creates a set of sub-problems for the specified node
 */
int create_subproblems(t_bbnode* node) {
    int num_new_subproblems = 0;

    //The number of levels in the graph
    int num_levels = g_blocklist.size()/2;

    //The maximum value for this level
    int endpoint = g_blocklist.size() - (num_levels - node->level - 1);
    //int endpoint = g_blocklist.size();

    if(node->left_blocks.size() < g_blocklist.size()/2) {
        for(int i = (int) node->index + 1; i <= endpoint; i++) {
            t_bbnode* subproblem = create_subproblem(node, LEFT, i);
            
            node->children[i] = subproblem;
            
            num_new_subproblems++;
        }
    }
    return num_new_subproblems;
}

/*
 * Creates a new subproblm based on the parent problem, and the next
 *   index to insert on the left side
 */
t_bbnode* create_subproblem(t_bbnode* parent, t_side side, int new_index) {
    if ((side == LEFT && parent->left_blocks.size() + 1 <= g_blocklist.size()/2) ||
        (side == RIGHT && parent->right_blocks.size() + 1 <= g_blocklist.size()/2)) {

        //There is room to add another sub-problem without upsetting the balance restirctions
        t_bbnode* subproblem = duplicate_subproblem(parent);

        subproblem->parent = parent;
        subproblem->level = parent->level + 1;
        subproblem->index = new_index;
        subproblem->status = UNBOUNDED;
        subproblem->is_full_solution = false;

        t_block_map::iterator block_iter = parent->free_blocks.find(new_index);
        assert(block_iter != parent->free_blocks.end());

        add_block_from_freelist(new_index, side, subproblem);

        if(subproblem->left_blocks.size() == g_blocklist.size() / 2) {
            finalize_solution(subproblem);
        }

        verify_subproblem(subproblem);

        return subproblem;
    } else {
        return NULL;
    }
}

t_bbnode* duplicate_subproblem(t_bbnode* subproblem) {
    t_bbnode* duplicate = new t_bbnode;
    duplicate->left_blocks = subproblem->left_blocks;
    duplicate->right_blocks = subproblem->right_blocks;
    duplicate->free_blocks = subproblem->free_blocks;
    //duplicate->children = subproblem->children;

    duplicate->parent = subproblem->parent;
    duplicate->level = subproblem->level;
    duplicate->index = subproblem->index;
    duplicate->status = subproblem->status;
    duplicate->is_full_solution = subproblem->is_full_solution;

    duplicate->UB = subproblem->UB;
    duplicate->LB = subproblem->LB;

    duplicate->max_left_index = subproblem->max_left_index;
    duplicate->max_right_index = subproblem->max_right_index;

    return duplicate;
}

/*
 * Creates the root node of the search tree
 *
 *   Note that this simply places the first block (index 1) on the 
 *   left side. Compared to the case where we place NO blocks on
 *   either side, this case ignores solutions where the same
 *   partitionings are used, but assigned to different sides.
 *
 *   E.g. 
 *      For the set of blocks [1, 2, 3, 4, 5, 6]:
 *
 *      This treats the solutions:
 *          L = [1, 2, 3],  R = [4, 5, 6]
 *
 *          and
 *
 *          L = [4, 5, 6], R = [1, 2, 3]
 *
 *          As equivalent
 *
 *   This is valid, since we ultimately care only about
 *   the partitioning and not which side got which blocks.
 */
t_bbnode* create_bnb_tree_root() {
    t_bbnode* root = new t_bbnode;
    root->max_left_index = 0;
    root->max_right_index = 0;

    root->level = 1;
    root->index = 1;
    root->parent = NULL;
    root->status = UNBOUNDED;
    root->is_full_solution = false;
    root->LB = SMALL_BOUND;
    root->UB = BIG_BOUND;
    
    root->free_blocks = g_blocklist;

    assert(g_blocklist.size() >= 2);

    if(g_args->tree_type != BINARY) {
        
        //The slot based tree starts out with an element in slot 1
        t_block_map::iterator blk1_iter = root->free_blocks.find(1);

        assert(blk1_iter != root->free_blocks.end());

        add_block_from_freelist(blk1_iter->first, LEFT, root);
    }

    return root;
}

