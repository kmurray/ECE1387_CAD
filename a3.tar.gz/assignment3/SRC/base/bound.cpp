//================================================================================================
// INCLUDES 
//================================================================================================
#include <assert.h>
#include <string.h>
#include <data_structs.h>
#include <util.h>
#include <initial_solution.h>
#include <branch_and_bound.h>
#include <bound.h>
#include <max_flow.h>
#include <verify.h>
#include <draw.h>

#include <algorithm>
using std::sort;


//================================================================================================
// INTERNAL FUNCTION DECLARTAIONS 
//================================================================================================
int worst_case_upper_bound(t_bbnode* subproblem);

int simple_greedy_upper_bound(t_bbnode* subproblem);
int find_most_connected_block_index(t_block super_block, t_block_map free_blocks);
pair<int,t_block> merge_blocks_in_side(t_bbnode* subproblem, t_side side);
    
int max_flow_lower_bound(t_bbnode* subproblem);

int multi_level_slot_lookahead(t_bbnode* subproblem, int level);
int slot_lookahead(t_bbnode* subproblem);
float calc_connectivity_ratio(t_bbnode* subproblem, t_block_pair free_block_pair);

int secondary_connection_lower_bound(t_bbnode* subproblem);
int secondary_connection_upper_bound(t_bbnode* subproblem);

bool is_connected_to_side(t_block_map side, t_block* block, int level);
int clausen_traff_lower_bound(t_bbnode* subproblem);
bool in_partition(t_block_map partition, t_block_map::iterator block_iter);

//================================================================================================
// EXTERNAL FUCTION IMPLIMENTATIONS
//================================================================================================
int find_subproblem_upper_bound(t_bbnode* subproblem) {
    int tightest_UB;

    DEBUG_PRINT(EXTRA_INFO, "\tCalculating UB:\n");
    
    //Worst case is the number of nets
    tightest_UB = g_netlist.size();

    //Simple greedy completion upper bound
    int greedy_UB = simple_greedy_upper_bound(subproblem);
    tightest_UB = min(tightest_UB, greedy_UB);

    DEBUG_PRINT(EXTRA_INFO, "\t\tTightest_UB: %d (Greedy_UB:%d)\n", tightest_UB, greedy_UB);
    return tightest_UB;
}

int find_subproblem_lower_bound(t_bbnode* subproblem) {
    DEBUG_PRINT(EXTRA_INFO, "\tCalculating LB:\n");
    int tightest_LB;
    /*
     *int initial_LB = evaluate_partial_solution_fixed_only(subproblem);
     *tightest_LB = initial_LB;
     */

    //Simple unbalanced LB
    /*
     *int secondary_connection_LB = secondary_connection_lower_bound(subproblem);
     *tightest_LB = max(tightest_LB, secondary_connection_LB);
     */

    //Slightly more complicated LB, based on the
    // Clausen-Traff Method
    int ct_LB = clausen_traff_lower_bound(subproblem);
    tightest_LB = ct_LB;

    //Lower bound by max flow
    //int mf_LB = max_flow_lower_bound(subproblem);
    //tightest_LB = max(tightest_LB, mf_LB);
    //tightest_LB = mf_LB;

    /*
     *int lookahead_LB = 0;
     *if(g_args->tree_type != BINARY) {
     *    int empty_slots = g_blocklist.size()/2 - subproblem->left_blocks.size();
     *    if(empty_slots <= SLOT_LOOKAHEAD_MAX_LEVEL && empty_slots > 0) {
     *        //Call at each level, e.g. 3, 2, 1
     *        lookahead_LB = multi_level_slot_lookahead(subproblem, empty_slots);
     *    }
     *    tightest_LB = max(tightest_LB, lookahead_LB);
     *}
     *int max_flow_LB = max_flow_lower_bound(subproblem);
     *tightest_LB = max(tightest_LB, max_flow_LB);
     */

    //DEBUG_PRINT(EXTRA_INFO, "\t\tTightest_LB: %d (Initial_LB: %d, Conn_LB: %d, CT_LB: %d LA_LB:%d)\n", tightest_LB, initial_LB, secondary_connection_LB, ct_LB, lookahead_LB);
    //DEBUG_PRINT(EXTRA_INFO, "\t\tTightest_LB: %d (CT_LB: %d MF_LB:%d)\n", tightest_LB, ct_LB, mf_LB);
    DEBUG_PRINT(EXTRA_INFO, "\t\tTightest_LB: %d (CT_LB: %d )\n", tightest_LB, ct_LB);

    subproblem->LB = tightest_LB;
    return tightest_LB;
}


//================================================================================================
// INTERNAL FUCTION IMPLIMENTATIONS
//================================================================================================


//*****************************
// Upper Bound fuctions
//*****************************
int worst_case_upper_bound(t_bbnode* subproblem) {
    //Worst case is every net crossing
    int worst_case_crossing_count = g_netlist.size();

    //Find the number of nets merged
    t_bbnode* completion = duplicate_subproblem(subproblem);
    pair<int, t_block> super_block_pair = merge_blocks_in_side(completion, LEFT);

    int worst_case_UB = worst_case_crossing_count - super_block_pair.first;

    delete completion;

    return worst_case_UB;
}

/*
 * Simple Greedy packing upper bound
 *
 *   This method aims to generate an upper bound by greedily 
 *   packing blocks to generate a completion of the given
 *   sub-problem
 */
int simple_greedy_upper_bound(t_bbnode* subproblem) {
    int simple_greedy_UB;
    
    if(strcmp(dump_solution_str(subproblem).c_str(), "L: 2 4, R: 1 3, F:") == 0 ) {
        printf("problematic upper bound\n");
    }

    if(subproblem->parent == NULL) {
        simple_greedy_UB = BIG_BOUND;

    } else {
        t_bbnode* completion = duplicate_subproblem(subproblem);

        t_block_map* side_blocks;
        t_side side;
        if(completion->left_blocks.size() >= completion->right_blocks.size()) {
            side_blocks = &completion->left_blocks;
            side = LEFT;
        } else {
            side_blocks = &completion->right_blocks;
            side = RIGHT;
        }

        while(side_blocks->size() < g_blocklist.size()/2) {
            //Merge all the blocks on left into a single super block preserving
            // connectivity.
            //This eliminates any nets contained completely within the left side
            pair<int,t_block> super_block_pair = merge_blocks_in_side(completion, side);
            t_block super_block = super_block_pair.second;

            //Find the free block most connected to the super_block
            int most_connected_block_index = find_most_connected_block_index(super_block, completion->free_blocks);

            //Add the most connected block to its new side
            add_block_from_freelist(most_connected_block_index, side, completion);
        }

        //Place the remaining blocks on right
        assert(completion->left_blocks.size() == g_blocklist.size()/2 || completion->right_blocks.size() == g_blocklist.size()/2);
        if (completion->free_blocks.size() != 0) {
            finalize_solution(completion);
        }

        simple_greedy_UB = evaluate_solution(completion);

        //Since the greedy upper bound isn't always gaurenteed to find a better solution
        //at a lower level, take the minimum of the previous upper bound and the newly
        // calculated one
        //simple_greedy_UB = min(subproblem->parent->UB, simple_greedy_UB);
        //assert(simple_greedy_UB <= subproblem->parent->UB);
        simple_greedy_UB = simple_greedy_UB;
        assert(simple_greedy_UB >= 0);


        delete completion;
    }

    return simple_greedy_UB;
}

/*
 * Finds the most connected block in free_blocks with respect to the super_block
 */
int find_most_connected_block_index(t_block super_block, t_block_map free_blocks) {
    int most_connected_block_index;
    int highest_connectivity = 0;

    //Check each free block
    for(t_block_map::iterator blk_iter = free_blocks.begin(); blk_iter != free_blocks.end(); blk_iter++) {
        int block_index = blk_iter->first;
        t_block* blk = blk_iter->second;

        int block_connectivity = 0;

        //For each net on this free block, count how many connections it has to the
        //  super block
        for(t_net_map::iterator net_iter = blk->nets.begin(); net_iter != blk->nets.end(); net_iter++) {
            int net_index = net_iter->first;

            if(super_block.nets.find(net_index) != super_block.nets.end()){
                block_connectivity++; 
            }
        }

        if(highest_connectivity == 0 || block_connectivity > highest_connectivity) {
            most_connected_block_index = block_index;
            highest_connectivity = block_connectivity;
        }
    }
    return most_connected_block_index;
}

/*
 * Merges the blocks on a specific side, collapsing nets that are completely internal 
 * to that side.
 */
pair<int,t_block> merge_blocks_in_side(t_bbnode* subproblem, t_side side) {

    t_block super_block;

    t_block_map* side_blocks;
    if(side == LEFT) {
        side_blocks = &subproblem->left_blocks;
    } else {
        side_blocks = &subproblem->right_blocks;
    }

    int duplicate_net_count = 0;
    // 1) First generate the super_block with a superset of all nets
    for(t_block_map::iterator blk_iter = side_blocks->begin(); blk_iter != side_blocks->end(); blk_iter++) {
        t_block* blk = blk_iter->second;
        for(t_net_map::iterator net_iter = blk->nets.begin(); net_iter != blk->nets.end(); net_iter++) {
            int net_index = net_iter->first;
            t_net* net = net_iter->second;

            //Add the net to the super_block if it doesn't exist
            if(super_block.nets.find(net_index) != super_block.nets.end()) {
                //It already exists
                duplicate_net_count++;
            } else {
                //Doesn't exist add it
                super_block.nets[net_index] = net;
            }
        }
    }

    //The following never activates?
/*
 *    int subsumed_net_count = 0;
 *    // 2) Remove any nets that are now contained completely within the super_block
 *    //      Do this by checking if the net exists in either the right_blocks or free_blocks
 *    for(t_net_map::iterator net_iter = super_block.nets.begin(); net_iter != super_block.nets.end(); net_iter++) {
 *            int net_index = net_iter->first;
 *
 *            if (subproblem->free_blocks.find(net_index) != subproblem->free_blocks.end() &&
 *                subproblem->right_blocks.find(net_index) != subproblem->right_blocks.end() ) {
 *                subsumed_net_count++;
 *                super_block.nets.erase(net_iter);
 *            }
 *    }
 */

    //printf("Super Block merging results -> Duplicate Nets Removed: %d, Nets Subsumed: %d\n", duplicate_net_count, subsumed_net_count);

    return pair<int,t_block>(duplicate_net_count, super_block);
}

//*****************************
// Lower Bound fuctions
//*****************************

int max_flow_lower_bound(t_bbnode* subproblem) {
    if(subproblem->left_blocks.size() > 0 && subproblem->right_blocks.size() > 0) {
        return solve_max_flow_subproblem(subproblem);
    } else {
        return 0;
    }
}

int multi_level_slot_lookahead(t_bbnode* subproblem, int level) {
    assert(subproblem->left_blocks.size() == g_blocklist.size()/2 - level);
    int multi_level_lower_bound = -1;
    if(level == 1) {
        //Base case
        multi_level_lower_bound = slot_lookahead(subproblem);
    } else {
        for(t_block_map::iterator blk_iter = subproblem->free_blocks.begin(); blk_iter != subproblem->free_blocks.end(); blk_iter++) {
            t_bbnode* new_subproblem = duplicate_subproblem(subproblem);

            add_block_from_freelist(blk_iter->first, LEFT, new_subproblem);

            //Recursion
            int this_block_lower_bound =  multi_level_slot_lookahead(new_subproblem, level-1);

            if(multi_level_lower_bound == -1) {
                //First iteration, need to initialize
                multi_level_lower_bound = this_block_lower_bound;

            } else {
                //Keep the worst value seen, so we don't over-estimate the lower bound
                multi_level_lower_bound = min(multi_level_lower_bound, this_block_lower_bound);
            }
        }
    }

    //printf("\t\tMulti-level slot lookahead LB: %d @ Level: %d, Left size: %zu\n", multi_level_lower_bound, level, subproblem->left_blocks.size());
    if(multi_level_lower_bound == -1) multi_level_lower_bound = 0;
    return multi_level_lower_bound;
}

/*
 * Looks ahead one slot to put in the best node
 */
int slot_lookahead(t_bbnode* subproblem) {
    if(subproblem->left_blocks.size() != g_blocklist.size()/2 - 1) {
        return 0;
    }

    //printf("Slot Lookahead\n");
    //Only valid if one empty slot is left
    assert(subproblem->left_blocks.size() == g_blocklist.size()/2 - 1);


    int best_blk_index;
    float best_blk_connectivity_ratio = -1.;
    for(t_block_map::iterator blk_iter = subproblem->free_blocks.begin(); blk_iter != subproblem->free_blocks.end(); blk_iter++) {
        t_bbnode* duplicate = duplicate_subproblem(subproblem);

        t_block* free_block = blk_iter->second;
        int free_block_index = blk_iter->first;
        //printf("\tChecking free block %d\n", free_block_index);

        float blk_connectivity_ratio = calc_connectivity_ratio(duplicate, t_block_pair(free_block_index, free_block));
        //printf("\t\tConnectivity Ratio: %.2f\n", blk_connectivity_ratio);

        if(blk_connectivity_ratio == -1. || blk_connectivity_ratio > best_blk_connectivity_ratio) {
            //printf("\t\tNew best ratio!\n");
            best_blk_index = free_block_index;
            best_blk_connectivity_ratio = blk_connectivity_ratio;
        }

        delete duplicate;
    }
    
    t_bbnode* completion = duplicate_subproblem(subproblem);

    add_block_from_freelist(best_blk_index, LEFT, completion);

    finalize_solution(completion);

    int lower_bound = evaluate_solution(completion);

    //printf("\tLower Bound: %d", lower_bound);

    delete completion;

    return lower_bound;
}

float calc_connectivity_ratio(t_bbnode* subproblem, t_block_pair free_block_pair) {
    int free_block_index = free_block_pair.first;
    t_block* free_block = free_block_pair.second;

    //Remove this block from the free block_map
    subproblem->free_blocks.erase(free_block_index);
    assert(subproblem->free_blocks.find(free_block_index) == subproblem->free_blocks.end());

    int left_connectivity = 0;
    int free_connectivity = 1; //Make the default free connectivity 1, this avoids divide by zero errors if the block isn't connected to any other free blocks, but still maintians the correct ranking
    for(t_net_map::iterator net_iter = free_block->nets.begin(); net_iter != free_block->nets.end(); net_iter++) {
        //printf("\t\tChecking free_block net: %d\n", net_iter->first);
        t_net* net = net_iter->second;

        for(t_block_map::iterator blk_iter = net->blocks.begin(); blk_iter != net->blocks.end(); blk_iter++) {
            //printf("\t\tChecking block: %d\n", blk_iter->first);
            //Check if the net connects to the left_super_block
            if(subproblem->left_blocks.find(blk_iter->first) != subproblem->left_blocks.end()) {
                //This net is connected to left
                left_connectivity++;

                //Check if it is also connected to free
                if(subproblem->free_blocks.find(blk_iter->first) != subproblem->free_blocks.end()) {
                    //It is, so moving this block wouldn't decrease the cut count
                    //  So don't bother counting this left connection
                    left_connectivity--;
                }

            } else if (subproblem->free_blocks.find(blk_iter->first) != subproblem->free_blocks.end()) {
                //This block connects only to othe free nets
                free_connectivity++;
            }
        }
    }

    assert(free_connectivity > 0);
    float connectivity_ratio = (float) left_connectivity / free_connectivity;
     
    return connectivity_ratio;
}

/*
 * The clausen_traff lower bound.
 *
 *   This method still enforces balance constraints, and
 *   generates a 'completion' of the given subproblem.
 *
 *   Fundamentally it assigns the verticies in the free list
 *   to the left and right partitions in such a way as to
 *   minimize the cut size, while ignoring any new cuts between
 *   the different elements of the free list (i.e. it only cares
 *   about nets connected to blocks that have already been 
 *   partitioned).
 *
 *   NOTE: This bound performs extremely poorly on the slot-style tree,
 *         since it does not count cuts amoung nodes that haven't been
 *         assigned to a side.  Sind the slot-style tree only assigns nodes
 *         to a the right side at the LAST level, this generates zero for the
 *         bound in all other cases.
 */
int clausen_traff_lower_bound(t_bbnode* subproblem) {
    int alpha = 0;
    int beta = 0;
    
    if(strcmp(dump_solution_str(subproblem).c_str(), "L: 1 2, R: 5, F: 6 3 4") == 0) {
        printf ("found bad bound\n");
    }
    multimap<int, t_block*> F_left;  //F1: Free blocks that have minimal cost in left 
    vector<t_block*> new_left_blocks;
    multimap<int, t_block*> F_right; //F2: Free blocks that have minimal cost in right
    vector<t_block*> new_right_blocks;
    multimap<int, t_block*> F_equal; //F3: Free blocks that have equal cost in left and right

    //Each free block
    for(t_block_map::iterator free_blk_iter = subproblem->free_blocks.begin(); free_blk_iter != subproblem->free_blocks.end(); free_blk_iter++) {
        t_block* free_blk = free_blk_iter->second;
        
        int left_cnt = 0;
        int right_cnt = 0;
        int delta = 0; //The cost penalty  of assigning free_block to 


        //The nets connected to the free block
        for(t_net_map::iterator net_iter = free_blk->nets.begin(); net_iter != free_blk->nets.end(); net_iter++) {
            t_net* net = net_iter->second; 

            //Blocks connected to these nets
            for(t_block_map::iterator connected_blk_iter = net->blocks.begin(); connected_blk_iter != net->blocks.end(); connected_blk_iter++) {

                if(in_partition(subproblem->left_blocks, connected_blk_iter)) {
                    left_cnt++; 
                }

                if(in_partition(subproblem->right_blocks, connected_blk_iter)) {
                    right_cnt++; 
                }
            }
        }


        //Calculate alpha: 
        //  The minimum cost of assigning each free vertex to
        //  either the left or right partition.
        //
        //  I.E. the inevitable cut
        alpha += min(left_cnt, right_cnt);
        
        //Calculate delta:
        //  The incremental cost of placing free_block on the 
        //  left, rather than right side
        delta = right_cnt - left_cnt;

        if(delta == 0) {
            F_equal.insert( pair<int, t_block*>(delta, free_blk));
        } else if (delta > 0) {
            //Lowest cost to put on right
            F_right.insert( pair<int, t_block*>(delta, free_blk));
        } else if (delta < 0) {
            //Lowest cost to put on left
            F_left.insert( pair<int, t_block*>(-1*delta, free_blk));
        }
    }
    
    //Calculate beta:
    //  The minimum incremental cost to re-balance the two
    //  partitions.
    int num_free_blocks_left = F_left.size();
    int num_free_blocks_right = F_right.size();
    size_t num_blocks_to_shift;
    if (subproblem->left_blocks.size() + F_left.size() > g_blocklist.size()/2) {
        //The number of blocks that need to be swapped to the other side
        num_blocks_to_shift =  subproblem->left_blocks.size() + F_left.size() - g_blocklist.size()/2;

        //Update total free blocks on left side
        num_free_blocks_left -= num_blocks_to_shift;
        num_free_blocks_right += num_blocks_to_shift;

        multimap<int, t_block*>::iterator first_it = F_left.begin();
        multimap<int, t_block*>::iterator last_it = F_left.end();
        last_it--;
        int first_delta = first_it->first;
        int last_delta = last_it->first;
        assert(first_delta <= last_delta);

        assert(F_left.size() >= num_blocks_to_shift);

        //Sum the negative deltas
        int cnt = 0;
        for(multimap<int, t_block*>::iterator it = F_left.begin(); it != F_left.end(); it++) {
            if(cnt < num_blocks_to_shift) {
                int incr_beta = it->first;
                beta += incr_beta;

                new_right_blocks.push_back(it->second);
                cnt++;
            } else {
                new_left_blocks.push_back(it->second);
            }
        }
        assert(cnt == num_blocks_to_shift);

    } else if (subproblem->right_blocks.size() + F_right.size() > g_blocklist.size()/2) {
        //The number of blocks that need to be swapped to the other side
        num_blocks_to_shift =  subproblem->right_blocks.size() + F_right.size() - g_blocklist.size()/2;

        //Update total free blocks on right side
        num_free_blocks_right -= num_blocks_to_shift;
        num_free_blocks_left += num_blocks_to_shift;

        multimap<int, t_block*>::iterator first_it = F_right.begin();
        multimap<int, t_block*>::iterator last_it = F_right.end();
        last_it--;
        int first_delta = first_it->first;
        int last_delta = last_it->first;
        assert(first_delta <= last_delta);

        assert(F_right.size() >= num_blocks_to_shift);

        //Sum the positive deltas
        int cnt = 0;
        for(multimap<int, t_block*>::iterator it = F_right.begin(); it != F_right.end(); it++) {
            if(cnt < num_blocks_to_shift) {
                int incr_beta = it->first;
                beta += incr_beta;

                new_left_blocks.push_back(it->second);
                cnt++;
            } else {
                new_right_blocks.push_back(it->second);
            }
        }
        assert(cnt == num_blocks_to_shift);
    }

    //Calculate gamma:
    //  The minimum cut on the uncounted free_block to free_block connections using max flow
    //  TODO: Doesn't handle the case where all blocks are in F_equal, but may still be partitioned
    //        To handle this, check the number of emtpy slots and make sure it can't all fit in one side
    //        of the partition
    int gamma = 0;
/*
 *    if(num_free_blocks_left > 0 && num_free_blocks_right > 0) {
 *        //Free blocks are going into both partitions
 *        //  There fore there must be some minimum number of
 *        //  internal nets cut
 *        //
 *        //  Use multiple iterations of max_flow to find this cut
 *        gamma = min_cut_free_block_internal_nets(subproblem);
 *
 *    } else {
 *        //Can not gaurentee that all blocks will end up on one side.
 *        //  Therefore, set gamma to zero, since the internal nets may not
 *        //  be cut.
 *        gamma = 0;
 *    }
 */

    t_bbnode* completion = duplicate_subproblem(subproblem);

    //Actually shift the left and right blocks
    // DO NOT shift the free blocks (to maintain a lower bound?)
    for(vector<t_block*>::iterator left_blk_it = new_left_blocks.begin(); left_blk_it != new_left_blocks.end(); left_blk_it++) {
        t_block* blk = *left_blk_it;

        add_block_from_freelist(blk->map_index, LEFT, completion);
    }
    for(vector<t_block*>::iterator right_blk_it = new_right_blocks.begin(); right_blk_it != new_right_blocks.end(); right_blk_it++) {
        t_block* blk = *right_blk_it;

        add_block_from_freelist(blk->map_index, RIGHT, completion);
    }

    //The actual lower bound
    int lower_bound = evaluate_partial_solution_fixed_only(subproblem) + alpha + beta + gamma; 

    int tight_LB = evaluate_partial_solution_fixed_only(completion);

    printf("\t\t\tCT_LB: %d CT_COMP_LB: %d\n", lower_bound, tight_LB);

    return lower_bound;
}

bool in_partition(t_block_map partition, t_block_map::iterator block_iter) {
    t_block* block = block_iter->second;
    t_block_map::iterator found = partition.find(block->map_index);
    if(found == partition.end()) {
        //Didn't find it
        return false;
    } else {
        //Found it
        return true;
    }
}

/*
 * Take all of the unpartitioned nets (blocks in subproblem's free_blocks block_map)
 * and determine if they are connected to blocks that have been placed on left side.
 *
 * If they have 
 */
int secondary_connection_lower_bound(t_bbnode* subproblem) {
    int cut_count = 0;

    for(t_block_map::iterator blk_iter = subproblem->left_blocks.begin(); blk_iter != subproblem->left_blocks.end(); blk_iter++) {

        t_block* left_blk = blk_iter->second;

        //Assume everything on free ends up on right, even though this would probaly violate balance
        if(is_connected_to_side(subproblem->free_blocks, left_blk, 0)) {
            cut_count++;        
        }

    }
    return cut_count;
}

/*
 * Take all nets not partitioned in this subproblem
 * with atleast two unpartitioned blocks - then
 * ensure place atleast one of these blocks on
 * each side.  Ensuring we maximize the crossing
 * count (create an upper bound), without regard for
 * balance.
 */
int secondary_connection_upper_bound(t_bbnode* subproblem) {
    return 0; //Unimp 
}

/*
 * Determines if the specified 'block', is connected (possibly through
 * several level of indirection) to any of the blocks in 'side'.
 *
 * Returns true if it is connected, false otherwise.
 */
bool is_connected_to_side(t_block_map side, t_block* block, int level) {
    //Nets connected to this block
    for(t_net_map::iterator net_iter = block->nets.begin(); net_iter != block->nets.end(); net_iter++) {
        t_net* net = net_iter->second;

        //Blocks on this net
        for(t_block_map::iterator connected_block_iter = net->blocks.begin(); connected_block_iter != net->blocks.end(); connected_block_iter++) {

            //See if connected_block is in the 'side' block map
            t_block_map::iterator found_iter = side.find(connected_block_iter->first);

            if(found_iter != side.end()) {
                //Successfully found
                return true;
            } else if (level < IS_CONNECTED_MAX_LEVEL) {
                return is_connected_to_side(side, connected_block_iter->second, level+1);
            }
        }
    }

    //Nothing was connected
    return false;
}


