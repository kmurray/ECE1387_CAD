#ifndef MAX_FLOW_H
#define MAX_FLOW_H
//================================================================================================
// INCLUDES 
//================================================================================================

//================================================================================================
// EXTERNAL GLOBAL VARIABLES 
//================================================================================================

//================================================================================================
// GLOBAL FUNCTION DECLARATIONS 
//================================================================================================
int solve_max_flow_subproblem(t_bbnode* subproblem);

int min_cut_free_block_internal_nets(t_bbnode* subproblem);
//================================================================================================
// PREPROCESSOR DEFINES 
//================================================================================================

//================================================================================================
// LOCACL DATA STURCTURES
//================================================================================================

typedef struct s_max_flow t_max_flow; //the actual problem
typedef struct s_mf_node t_mf_node;
typedef struct s_mf_edge t_mf_edge;
typedef struct s_path t_path;
typedef enum e_mf_node_type {DEFAULT, SOURCE, SINK} t_mf_node_type;

typedef vector<t_mf_node*> t_mf_node_vec;
typedef vector<t_mf_edge*> t_mf_edge_vec;
typedef queue<t_mf_node*> t_mf_node_queue;
typedef queue<t_block*> t_block_queue;

//A max flow problem
struct s_max_flow {
    //The original flow graph
    t_mf_node* G_source;
    t_mf_node* G_sink;
    t_mf_node_vec G_nodes;
    t_mf_edge_vec G_edges;

    //the residual network graph
    t_mf_edge_vec Gf_edges;
};

//A node in a max flow problem
struct s_mf_node {
    //The edges adjacent to this node
    t_mf_edge_vec G_edges;
    t_mf_edge_vec Gf_edges;

    //The type of this node
    t_mf_node_type type;
    int index; //Only valid if type == DEFAULT

    bool traversed;
    int label;
};

//An edge in a max flow problem
struct s_mf_edge {
    int pos_capacity;
    int pos_flow;

    int neg_capacity;
    int neg_flow;

    //The nodes adjacent to this edge
    t_mf_node_vec nodes;
};

struct s_path {
    t_mf_edge_vec edges;
    int residual_capacity;
};

#endif
