#ifndef DATA_STRUCTS_H
#define DATA_STRUCTS_H

#include <map>
#include <vector>
#include <queue>
#include <algorithm>

using std::vector;
using std::map;
using std::multimap;
using std::pair;
using std::priority_queue;
using std::queue;
using std::sort;


typedef struct s_CHIP t_CHIP;
typedef struct s_block t_block;
typedef struct s_net t_net;
typedef struct s_bbnode t_bbnode;
typedef struct s_stats t_stats;

typedef map<int, t_block*> t_block_map;
typedef pair<int, t_block*> t_block_pair;

typedef map<int, t_net*> t_net_map;
typedef pair<int, t_net*> t_net_pair;

typedef map<int, t_bbnode*> t_bbnode_map;
typedef pair<int, t_bbnode*> t_bbnode_pair;

struct CompareBBNode : public std::binary_function<t_bbnode_pair, t_bbnode_pair, bool> {  
  bool operator()(const t_bbnode_pair lhs, const t_bbnode_pair rhs) {  
     return lhs.first < rhs.first;  
  }  
};
typedef priority_queue<t_bbnode_pair, vector<t_bbnode_pair>, CompareBBNode> t_bbnode_queue;

typedef enum e_boolean {FALSE = 0, TRUE} t_boolean;
typedef enum e_side {LEFT = 0, RIGHT} t_side;

typedef enum e_status {NORMAL, UNBOUNDED, PRUNED_BOUND, PRUNED_BALANCE, OLD_BEST, BEST} t_status;

typedef enum e_tree_type {SLOT, BINARY} t_tree_type;



/*
 * The placement primitive, representing a
 * std cell, or pseudo cell
 */
struct s_block {
    int index;
    int map_index;

    t_net_map nets;
};

/*
 * A logical net that may fan out to multiple blocks
 */
struct s_net {
    int index;

    t_block_map blocks;
};


/*
 *  A (partial) solution in the brand and bound
 *  decision tree.
 */
struct s_bbnode {
    t_block_map left_blocks;
    t_block_map right_blocks;
    t_block_map free_blocks;
    t_bbnode_map children;

    //Node information
    t_bbnode* parent;
    int level;
    int index;
    t_status status;
    bool is_full_solution;
    int LB; //The lower bound
    int UB;

    //The maximum index found in the left
    int max_left_index;
    int max_right_index;
};

struct s_stats {
    double num_nodes_explored;
    double num_nodes_pruned;
    double total_num_solutions;
    double total_num_nodes;

};


//Global variables
extern t_block_map g_blocklist;
extern t_net_map g_netlist;
extern t_bbnode* g_search_root;
extern int g_best_UB;
extern int g_best_soln;
extern t_stats g_stats;;
#endif
