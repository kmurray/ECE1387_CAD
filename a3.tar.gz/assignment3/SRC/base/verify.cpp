//================================================================================================
// INCLUDES 
//================================================================================================
#include <assert.h>
#include <data_structs.h>
#include <util.h>
#include <verify.h>
#include <sstream>
#include <string>


//================================================================================================
// INTERNAL FUNCTION DECLARTAIONS 
//================================================================================================
int evaluate_partial_solution_fixed_only(t_bbnode* soln);

void check_for_common_elements(t_block_map a, t_block_map b);
void check_block_map_consistency(t_block_map a);
//================================================================================================
// INTERNAL FUCTION IMPLIMENTATIONS
//================================================================================================

int evaluate_solution(t_bbnode* soln) {
    assert(soln->free_blocks.size() == 0);
    assert(soln->left_blocks.size() == soln->right_blocks.size());
    assert(soln->left_blocks.size() + soln->right_blocks.size() == g_blocklist.size());

    int cost = evaluate_partial_solution_fixed_only(soln);

    return cost;
}

//The crossing count of blocks that have been fixed to opposite sides
int evaluate_partial_solution_fixed_only(t_bbnode* soln) {
    int cut_count = 0;

    //t_net_map seen_nets;

    //Each block on the left side
    for(t_block_map::iterator left_iter = soln->left_blocks.begin(); left_iter != soln->left_blocks.end(); left_iter++) {
        t_block* left_block = left_iter->second;

        //Each net on a left block
        for(t_net_map::iterator left_net_iter = left_block->nets.begin(); left_net_iter != left_block->nets.end(); left_net_iter++) {
            t_net* left_net = left_net_iter->second;
            int net_blocks_on_free = 0;
            int net_blocks_on_right = 0;

            //Keep track of the nets we have looked at, so we don't 
            //double count
            /*
             *if(seen_nets.find(left_net_iter->first) != seen_nets.end()) {
             *    //Found the net, so we have already looked at it
             *    continue;
             *}
             *seen_nets[left_net_iter->first] = left_net; //Mark this new net as seen
             */

            //Check if any block on this left net is on the right
            for(t_block_map::iterator block_iter = left_net->blocks.begin(); block_iter != left_net->blocks.end(); block_iter++) {
                t_block* block = block_iter->second;

                if(left_block == block) continue;
                // Count how many of this net's blocks are in the right and free lists respectively


                //find() returns end() if the block isn't in the map
                if(soln->right_blocks.find(block->map_index) != soln->right_blocks.end()) {
                    net_blocks_on_right++;
                }

                if(soln->free_blocks.find(block->map_index) != soln->free_blocks.end()) {
                    net_blocks_on_free++;
                }
            }

            //Only increment the count if ALL blocks on the net have been placed (i.e. net_blocks_on_free ==0)
            //  AND there are blocks on the right side (which means one crossing since this net is already 
            //  connected to the left)
            if (net_blocks_on_free == 0 && net_blocks_on_right > 0) {
                cut_count += 1; //Only adds one to the cut count
            }
        }
    }

    return cut_count;
}

void dump_solution(t_bbnode* soln) {
    printf("Left: %zu blocks\n", soln->left_blocks.size());
    dump_block_map(soln->left_blocks);

    printf("Right: %zu blocks\n", soln->right_blocks.size());
    dump_block_map(soln->right_blocks);

    printf("Free: %zu blocks\n", soln->free_blocks.size());
    dump_block_map(soln->free_blocks);
}

std::string dump_solution_str(t_bbnode* soln) {
    /*
     *t_bbnode* node = soln;
     *while(node != NULL) {
     *    std::ostringstream oss;
     *    if(node->parent != NULL) {
     *        oss << ", ";
     *        oss << node->max_left_index;
     *    } else {
     *        oss << node->max_left_index;
     *    }
     *    str.insert(0, oss.str());
     *    node = node->parent;
     *}
     */

    std::ostringstream oss;
    oss << "L:";
    for(t_block_map::iterator left_blk_iter = soln->left_blocks.begin(); left_blk_iter != soln->left_blocks.end(); left_blk_iter++) {
        oss << " " << left_blk_iter->second->index; 
    }
    oss << ", R:";
    for(t_block_map::iterator right_blk_iter = soln->right_blocks.begin(); right_blk_iter != soln->right_blocks.end(); right_blk_iter++) {
        oss << " " << right_blk_iter->second->index; 
    }
    oss << ", F:";
    for(t_block_map::iterator free_blk_iter = soln->free_blocks.begin(); free_blk_iter != soln->free_blocks.end(); free_blk_iter++) {
        oss << " " << free_blk_iter->second->index; 
    }
    return oss.str();
}

void dump_block_map(t_block_map blk_map) {
    int size = blk_map.size();
    int cnt = 0;
    for(t_block_map::iterator blk_iter = blk_map.begin(); blk_iter != blk_map.end(); blk_iter++) {
        t_block* blk = blk_iter->second;
        
        int fanout = blk->nets.size();
        int connected_blocks = 0;
        for(t_net_map::iterator net_iter = blk->nets.begin(); net_iter != blk->nets.end(); net_iter++) {
            t_net* net = net_iter->second;
            connected_blocks += net->blocks.size();
        }

        printf("    BLK: %d (MapIdx: %d FO: %d, ConnBlks: %d)\n", blk->index, blk_iter->first, fanout, connected_blocks);
        cnt++;
    }
    assert(size == cnt);
}

void verify_subproblem(t_bbnode* subproblem) {
    //Size must add up
    assert(subproblem->left_blocks.size() + subproblem->right_blocks.size() + subproblem->free_blocks.size() == g_blocklist.size());

    //Check for no repeated elements within each block_map
    check_block_map_consistency(subproblem->left_blocks);
    check_block_map_consistency(subproblem->right_blocks);
    check_block_map_consistency(subproblem->free_blocks);
    
    //check for no repeated elements between block_maps
    check_for_common_elements(subproblem->left_blocks, subproblem->right_blocks);
    check_for_common_elements(subproblem->left_blocks, subproblem->free_blocks);
    check_for_common_elements(subproblem->right_blocks, subproblem->free_blocks);
}

void check_block_map_consistency(t_block_map a) {
    map<int, bool> seen_indexes;

    for(t_block_map::iterator a_iter = a.begin(); a_iter != a.end(); a_iter++) {
        t_block* a_blk = a_iter->second;

        //Should not have seen this index before
        assert(seen_indexes.find(a_blk->index) == seen_indexes.end());

        //Mark as seen
        seen_indexes[a_blk->index] = true;
    }
}

void check_for_common_elements(t_block_map a, t_block_map b) {
    for(t_block_map::iterator a_iter = a.begin(); a_iter != a.end(); a_iter++) {
        for(t_block_map::iterator b_iter = b.begin(); b_iter != b.end(); b_iter++) {
            t_block* a_blk = a_iter->second;
            t_block* b_blk = b_iter->second;

            assert(a_blk->index != b_blk->index);
        }
    }
}

void check_bound_consistensy(t_bbnode* subproblem) {
    //Check the bounds of each parent, working up 
    // from the bottom of the tree
    t_bbnode* child = subproblem;
    while(child->parent != NULL) {
        // NOT TRUE: Child's UB must be better (lower) or the same as parent
        //assert(child->UB <= child->parent->UB);

        //Child's LB must be better (higher) or the same as parent
        assert(child->LB >= child->parent->LB);

        //Move up a level
        child = child->parent;
    }
}

void init_stats() {
    g_stats.num_nodes_explored = 0;
    g_stats.num_nodes_pruned = 0;

    g_stats.total_num_solutions = 0;
    g_stats.total_num_nodes = 0;
}

void print_stats() {
    printf("\nStats:\n");
    printf("    Total Num Nodes             : %.2e\n", g_stats.total_num_nodes);
    printf("    Nodes Traversed             : %.2e\n", g_stats.num_nodes_explored);
    printf("    Total Num Soln              : %.2e\n", g_stats.total_num_solutions);
    printf("    Nodes Pruned                : %.2e\n", g_stats.num_nodes_pruned);
    printf("    Nodes Traversed (%% #soln)  : %.2f%%\n", (double) 100*g_stats.num_nodes_explored / g_stats.total_num_solutions);
}
