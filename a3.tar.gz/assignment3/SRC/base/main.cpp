#include <data_structs.h>
#include <util.h>
#include <draw.h>
#include <argparse.h>
#include <parse_input.h>
#include <initial_solution.h>
#include <branch_and_bound.h>
#include <verify.h>

//the global data sturctures
t_block_map g_blocklist;
t_net_map g_netlist;
t_bbnode* g_search_root;
int g_best_UB;
int g_best_soln;
t_stats g_stats;

//Argument parsing stuff
extern struct argp argp;
t_arguments* g_args;

int main (int argc, char** argv) {
    //Parse Arguments
    g_args = parse_args(argc, argv);

    init_stats();

    printf("Parsing Netlist...\n");
    parse_netlist(g_args->netlist_file);
    printf("DONE\n");
    
    printf("Block List:\n");
    dump_block_map(g_blocklist);

    if(!g_args->no_disp) {
        char buf[50] = "kpartition graphics";
        init_graphics(buf);
        //start_interactive_graphics();
    }
    
    //The worst case cut size is the total number of nets
    g_best_UB = g_netlist.size();

    t_bbnode* initial_solution = find_best_initial_solution();


    printf("Initial solution cut count: %d\n", evaluate_solution(initial_solution));
    dump_solution(initial_solution);

    t_bbnode* final_solution = solve_bnb(initial_solution);

    printf("\nFinal solution cut count: %d\n", evaluate_solution(final_solution));
    dump_solution(final_solution);

    print_stats();

    start_interactive_graphics();
    printf("\nTool Finished - exiting...\n");
    return 0;
}

