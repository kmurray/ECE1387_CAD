
//================================================================================================
// INCLUDES 
//================================================================================================
#include <sstream>
#include <assert.h>
#include <string.h>
#include <data_structs.h>
#include <util.h>
#include <initial_solution.h>
#include <branch_and_bound.h>
#include <bound.h>
#include <verify.h>
#include <draw.h>
#include <max_flow.h>

//================================================================================================
// INTERNAL FUNCTION DECLARTAIONS 
//================================================================================================
int solve_max_flow(t_max_flow* max_flow_problem);

void delete_max_flow_problem(t_max_flow* mf_problem);

int calc_flow(t_max_flow* mf_prob);
t_path* find_augmented_path(t_max_flow* mf_prob);
t_path* find_trace_back(t_mf_node* source, t_mf_node* sink);
t_mf_edge* find_matching_G_edge(t_mf_edge* Gf_edge);
void reset_node_traversal_markers(t_max_flow* mf_prob);
t_mf_node* find_adjacent_node(t_mf_node* node, t_mf_edge* edge);

void update_residual_network(t_max_flow* mf_prob);
void create_residual_network(t_max_flow* mf_prob);
t_mf_edge* duplicate_edge(t_mf_edge* edge);
void update_residual_edge(t_mf_edge* Gf_edge, t_mf_edge* G_edge);
int residual_capacity(t_mf_edge* edge);
void add_residual_edge(t_max_flow* mf_prob, t_mf_edge* G_edge, t_mf_edge* Gf_edge);

t_max_flow* convert_subproblem_to_max_flow(t_bbnode* subproblem); 
void add_edge(t_max_flow* mf_prob, map<t_block*, t_mf_node*> node_map, t_block* start_blk, t_block* finish_blk);

t_max_flow* convert_min_free_block_cut_subproblem_to_max_flow(t_bbnode* subproblem, t_block* source, t_block* sink);

void verify_max_flow_problem(t_max_flow* max_flow_problem);
void verify_max_flow_node(t_mf_node* node);

std::string get_node_name(t_mf_node* node);
void dump_edge(t_mf_edge* edge);
void dump_path(t_path* path);
void dump_mf_graph(t_max_flow* mf_prob);
//================================================================================================
// EXTERNAL FUCTION IMPLIMENTATIONS
//================================================================================================
int solve_max_flow_subproblem(t_bbnode* subproblem) {
    /*
     *if(strcmp(dump_solution_str(subproblem).c_str(), "L: 1 2, R: 3 4, F:") == 0) {
     *    printf("Bad max flow\n");
     *}
     */

    //Convert the subproblem into a maxflow formulation
    //  This collapes partitioned nodes on the left and right into single
    //  source and sink nodes.
    t_max_flow* max_flow_problem = convert_subproblem_to_max_flow(subproblem); 

    //Solve the max flow problem
    //  The value of max_flow is also the min cut of collapsed subproblem
    //  FIXME: This gives an off by one error for cct2 and cct3
    int max_flow = solve_max_flow(max_flow_problem);

    //This may not always be correct
    //  TODO: verify when this is valid
    //int partitioned_cut_count = evaluate_partial_solution_fixed_only(subproblem);
    int partitioned_cut_count = 0;

    delete_max_flow_problem(max_flow_problem);

    int lower_bound = max_flow + partitioned_cut_count;
    return lower_bound;
}

void delete_max_flow_problem(t_max_flow* mf_prob) {
    for(t_mf_edge_vec::iterator G_edge_iter = mf_prob->G_edges.begin(); G_edge_iter != mf_prob->G_edges.end(); G_edge_iter++) {
        t_mf_edge* G_edge = *G_edge_iter;
        delete G_edge;
    }
    for(t_mf_edge_vec::iterator Gf_edge_iter = mf_prob->Gf_edges.begin(); Gf_edge_iter != mf_prob->Gf_edges.end(); Gf_edge_iter++) {
        t_mf_edge* Gf_edge = *Gf_edge_iter;
        delete Gf_edge;
    }
    for(t_mf_node_vec::iterator G_node_iter = mf_prob->G_nodes.begin(); G_node_iter != mf_prob->G_nodes.end(); G_node_iter++) {
        t_mf_node* G_node = *G_node_iter;
        delete G_node;
    }
    delete mf_prob;
}

/*
 * We are intested in finding the minimum number of cuts between nets
 *   internal to the subproblem's free blocks
 */
int min_cut_free_block_internal_nets(t_bbnode* subproblem) {
    int min_cut;
    bool found_cut = false;

    for(t_block_map::iterator blk_iter = subproblem->free_blocks.begin(); blk_iter != subproblem->free_blocks.end(); blk_iter++) {
        t_block* source = blk_iter->second;

        for(t_block_map::iterator blk_iter = subproblem->free_blocks.begin(); blk_iter != subproblem->free_blocks.end(); blk_iter++) {
            t_block* sink = blk_iter->second;

            if(source == sink) continue;

            /*
             *  First convert the subproblem into a max flow problem
             */
            t_max_flow* mf_prob = convert_min_free_block_cut_subproblem_to_max_flow(subproblem, source, sink);

            /*
             *  Find the lowest cut (max flow)
             */
            int cut = solve_max_flow(mf_prob);
            
            /*
             *  Keep the lowest cut found
             */
            if(!found_cut) {
                //First iteration
                min_cut = cut;
                found_cut = true;
            } else {
                //Keep the smallest
                min_cut = min(min_cut, cut);

                //Can not get any smaller than zero, so no point checking any further
                if(min_cut == 0) return min_cut;
            }

            //Clean up
            delete_max_flow_problem(mf_prob);

        }
    }
    assert(found_cut);
    return min_cut;
}

//================================================================================================
// INTERNAL FUCTION IMPLIMENTATIONS
//================================================================================================
/*
 * Solve max flow using the Ford-Fulkerson Method
 */
int solve_max_flow(t_max_flow* max_flow_problem) {
    //Create the residual network
    create_residual_network(max_flow_problem);

    verify_max_flow_problem(max_flow_problem);

    //dump_mf_graph(max_flow_problem);

    DEBUG_PRINT(EXTRA_INFO, "\t\tMax Flow (Ford-Fulkerson):\n");

    int cnt = 1;

    int prev_flow = calc_flow(max_flow_problem);
    assert(prev_flow == 0);

    int curr_flow;

    t_path* augmented_path = find_augmented_path(max_flow_problem);
    while(augmented_path != NULL) {

        //dump_path(augmented_path);

        for(t_mf_edge_vec::iterator path_edge_iter = augmented_path->edges.begin(); path_edge_iter != augmented_path->edges.end(); path_edge_iter++) {
            t_mf_edge* G_edge = *path_edge_iter;

            //Update the flow
            G_edge->pos_flow += augmented_path->residual_capacity;
            assert(G_edge->pos_flow <= G_edge->pos_capacity);
        }

        curr_flow = calc_flow(max_flow_problem);
        //Flow should increase by atleast 1 every iteration
        assert(prev_flow < curr_flow);

        DEBUG_PRINT(EXTRA_INFO, "\t\t    Iteration: %d, Max Flow: %d\n", cnt, curr_flow);

        //Update the residual network
        update_residual_network(max_flow_problem);

        //Sanity check
        verify_max_flow_problem(max_flow_problem);

        //Find the next augmented path
        augmented_path = find_augmented_path(max_flow_problem);

        //dump_mf_graph(max_flow_problem);

        //Update
        prev_flow = curr_flow;
        cnt++;
    }

    delete augmented_path;
    
    //The flow graph is now at maximum flow
    int max_flow = calc_flow(max_flow_problem);


    return max_flow;
}

int calc_flow(t_max_flow* mf_prob) {
    //To calculate the maximum flow, calculate the total flow out of the source
    int max_flow = 0;
    for(t_mf_edge_vec::iterator edge_iter = mf_prob->G_source->G_edges.begin(); edge_iter != mf_prob->G_source->G_edges.end(); edge_iter++) {
        t_mf_edge* G_edge = *edge_iter;
        assert(G_edge->neg_flow == 0);

        max_flow += G_edge->pos_flow;
    }

    return max_flow;
}

t_path* find_augmented_path(t_max_flow* mf_prob) {
    int label_count = 0;
    
    //Breadth first search
    
    //Label the first node
    mf_prob->G_source->traversed = true;
    mf_prob->G_source->label = label_count;

    //Create the queue
    t_mf_node_queue node_queue;

    //Enqueue the first node
    node_queue.push(mf_prob->G_source);


    bool found_path = false;
    while(!node_queue.empty()) {
        t_mf_node* node = node_queue.front();
        node_queue.pop();

        //Increment the label
        label_count++;

        if(node == mf_prob->G_sink) {
            //Found it
            node->traversed = true;
            found_path = true;
            //break;
        }


        //Each edge of node
        for(t_mf_edge_vec::iterator Gf_edge_iter = node->Gf_edges.begin(); Gf_edge_iter != node->Gf_edges.end(); Gf_edge_iter++) {
            t_mf_edge* Gf_edge = *Gf_edge_iter;

            //The edge's associated node
            t_mf_node* adjacent_node = find_adjacent_node(node, Gf_edge);

            assert(adjacent_node != node);

            //Mark only if not traversed, and has residual capacity > 0
            if(!adjacent_node->traversed && Gf_edge->pos_flow > 0) {
                adjacent_node->traversed = true;
                adjacent_node->label = label_count;
                node_queue.push(adjacent_node);
            }
        }
    }

    t_path* path;


    if(found_path) {
        //Back trace
        path = find_trace_back(mf_prob->G_source, mf_prob->G_sink);
        if(path == NULL) {
            printf("\t\t    Found no path during traceback\n");
            dump_mf_graph(mf_prob);
            assert(0);
        }
    
    } else {
        path = NULL;
        DEBUG_PRINT(EXTRA_INFO, "\t\t    Found no path during expansion\n");
    }
    
    reset_node_traversal_markers(mf_prob);
    return path;
}

void reset_node_traversal_markers(t_max_flow* mf_prob) {
    for(t_mf_node_vec::iterator node_iter = mf_prob->G_nodes.begin(); node_iter != mf_prob->G_nodes.end(); node_iter++) {
        t_mf_node* node = *node_iter;

        node->traversed = false;
        node->label = -1;
    }
    assert(mf_prob->G_source->traversed == false);
    assert(mf_prob->G_sink->traversed == false);

}

t_path* find_trace_back(t_mf_node* source, t_mf_node* sink) {
    t_path* path = new t_path; 

    int min_residual_capacity = -1;


    int lowest_label = sink->label;

    t_mf_node* node = sink;
    t_mf_node* prev_node;
    while(node != source) { 

        //For the edges of this node
        for(int i = 0; i < node->Gf_edges.size(); i++) {
            t_mf_edge* Gf_edge = node->Gf_edges.at(i);
            assert(Gf_edge != NULL);

            t_mf_edge* G_edge = find_matching_G_edge(Gf_edge); 

            //The adjacent_node attached by Gf_edge
            t_mf_node* adjacent_node = find_adjacent_node(node, Gf_edge);

            //The adjacent node must:
            //  1) Have been traversed (i.e. it is connected to source)
            //  2) Positive flow on this edge must be > 0.  Since nodes may have multiple edges we want to pick
            //     a valid one
            //  3) Have a label value lower than previous (i.e. makes progress towards source)
            if(adjacent_node->traversed && Gf_edge->pos_flow > 0 && adjacent_node->label < lowest_label) {

                //Add the edge
                path->edges.push_back(G_edge);

                //Save the previous node
                prev_node = node;

                //Update node in preperation for the next iteration
                node = adjacent_node;

                //Update the lowest label seen
                lowest_label = adjacent_node->label;

                //Track the minimum capacity
                if(min_residual_capacity == -1) {
                    //First edge
                    min_residual_capacity = Gf_edge->pos_flow;
                } else {
                    //All other edges
                    min_residual_capacity = min(min_residual_capacity, Gf_edge->pos_flow);
                }

                break; //We have found the next segment, so continue traceback from there
            }
        }
    }
    if(node != source) {
        return NULL; //No path with positive minimum cost
    } else {

        assert(node == source);


        path->residual_capacity = min_residual_capacity;

        return path;
    }
}

t_mf_edge* find_matching_G_edge(t_mf_edge* Gf_edge) {
    assert(Gf_edge->nodes.size() == 2);
     t_mf_node* Gf_node_A = Gf_edge->nodes.at(0);
     t_mf_node* Gf_node_B = Gf_edge->nodes.at(1);


    //All the G_edges off of node A
    for(t_mf_edge_vec::iterator G_edge_iter = Gf_node_A->G_edges.begin(); G_edge_iter != Gf_node_A->G_edges.end(); G_edge_iter++) {
        t_mf_edge* G_edge = *G_edge_iter;

        t_mf_node* G_node_A = G_edge->nodes.at(0);
        t_mf_node* G_node_B = G_edge->nodes.at(1);

        if((G_node_A == Gf_node_A && G_node_B == Gf_node_B) ||
           (G_node_A == Gf_node_B && G_node_B == Gf_node_A)) {
            return G_edge; 
        }
    }

    //Should never get here
    assert(0);
}

t_mf_node* find_adjacent_node(t_mf_node* node, t_mf_edge* edge) {
    t_mf_node* adjacent_node;

    assert(edge->nodes.size() == 2);
    t_mf_node_vec::iterator adjacent_nodeA_it = edge->nodes.begin();
    t_mf_node_vec::iterator adjacent_nodeB_it = edge->nodes.begin() + 1;
    t_mf_node* adjacent_nodeA = *adjacent_nodeA_it;
    t_mf_node* adjacent_nodeB = *adjacent_nodeB_it;

    if(adjacent_nodeA == node) {
        adjacent_node = adjacent_nodeB;
    } else {
        adjacent_node = adjacent_nodeA;
    }

    assert(node != adjacent_node);
    return adjacent_node;
}

void update_residual_network(t_max_flow* mf_prob) {
    /*
     *Remove the old network
     */

    //First delete all the edges
    for(t_mf_edge_vec::iterator edge_iter = mf_prob->Gf_edges.begin(); edge_iter != mf_prob->Gf_edges.end(); edge_iter++) {
        t_mf_edge* edge = *edge_iter;
        delete edge;
    }
    //Now empty the vector
    mf_prob->Gf_edges.erase(mf_prob->Gf_edges.begin(), mf_prob->Gf_edges.end());
    assert(mf_prob->Gf_edges.size() == 0);

    //Then delete all the node references
    for(t_mf_node_vec::iterator node_iter = mf_prob->G_nodes.begin(); node_iter != mf_prob->G_nodes.end(); node_iter++) {
        t_mf_node* node = *node_iter;

        node->Gf_edges.erase(node->Gf_edges.begin(), node->Gf_edges.end());
        assert(node->Gf_edges.size() == 0);
    }

    //Create a new one
    create_residual_network(mf_prob);
}

void create_residual_network(t_max_flow* mf_prob) {
    for(t_mf_edge_vec::iterator edge_iter = mf_prob->G_edges.begin(); edge_iter != mf_prob->G_edges.end(); edge_iter++) {
        t_mf_edge* G_edge = *edge_iter;
        t_mf_edge* Gf_edge = duplicate_edge(G_edge);

        //Given an edge in G, update the edge in the residual graph
        update_residual_edge(Gf_edge, G_edge);


        //Add the edge to both the mf_prob, and to the associated nodes
        add_residual_edge(mf_prob, G_edge, Gf_edge);
    }
}

t_mf_edge* duplicate_edge(t_mf_edge* edge) {
    t_mf_edge* duplicate = new t_mf_edge;

    duplicate->pos_capacity = edge->pos_capacity;
    duplicate->pos_flow = edge->pos_flow;

    duplicate->neg_capacity = edge->neg_capacity;
    duplicate->neg_flow = edge->neg_flow;

    duplicate->nodes = edge->nodes;

    return duplicate;
}

void update_residual_edge(t_mf_edge* Gf_edge, t_mf_edge* G_edge) {
    Gf_edge->pos_flow = residual_capacity(G_edge);
    Gf_edge->pos_capacity = G_edge->pos_capacity;

    Gf_edge->neg_flow = G_edge->pos_flow; //Skew symmetry
    Gf_edge->neg_capacity = 0;
}

int residual_capacity(t_mf_edge* edge) {
    return edge->pos_capacity - edge->pos_flow;
}

void add_residual_edge(t_max_flow* mf_prob, t_mf_edge* G_edge, t_mf_edge* Gf_edge) {
    assert(Gf_edge != NULL);
    //Add the edge to the problem
    mf_prob->Gf_edges.push_back(Gf_edge); 

    //Two pin nets
    assert(G_edge->nodes.size() == 2);

    t_mf_node_vec::iterator node_A_it = G_edge->nodes.begin();
    t_mf_node_vec::iterator node_B_it = G_edge->nodes.begin() + 1;
    t_mf_node* node_A = *node_A_it;
    t_mf_node* node_B = *node_B_it;

    node_A->Gf_edges.push_back(Gf_edge);
    node_B->Gf_edges.push_back(Gf_edge);
}

t_max_flow* convert_subproblem_to_max_flow(t_bbnode* subproblem) {
    assert(subproblem->left_blocks.size() > 0);
    assert(subproblem->right_blocks.size() > 0);

    t_max_flow* mf_prob = new t_max_flow;

    /*
     *  Convert blocks
     */
    //Create the source and sink nodes
    t_mf_node* source = new t_mf_node;
    source->type = SOURCE;
    source->traversed = false;
    t_mf_node* sink = new t_mf_node;
    sink->type = SINK;
    sink->traversed = false;

    //Add source and sink to the problem
    mf_prob->G_source = source;
    mf_prob->G_sink = sink;
    mf_prob->G_nodes.push_back(source);
    mf_prob->G_nodes.push_back(sink);

    //Quick look-up for new nodes
    map<t_block*,t_mf_node*> node_map;

    //Initialize map for left block
    for(t_block_map::iterator blk_iter = subproblem->left_blocks.begin(); blk_iter != subproblem->left_blocks.end(); blk_iter++) {
        t_block* block = blk_iter->second;

        node_map[block] = source;
    }
    

    //Initialize map for right block
    for(t_block_map::iterator blk_iter = subproblem->right_blocks.begin(); blk_iter != subproblem->right_blocks.end(); blk_iter++) {
        t_block* block = blk_iter->second;

        node_map[block] = sink;
    }

    //Convert each free block
    for(t_block_map::iterator blk_iter = subproblem->free_blocks.begin(); blk_iter != subproblem->free_blocks.end(); blk_iter++) {
        t_block* block = blk_iter->second;

        t_mf_node* new_node = new t_mf_node;
        new_node->type = DEFAULT;
        new_node->index = block->index;
        new_node->traversed = false;

        //Map Look up from block->node
        node_map[block] = new_node;

        //Add the node to the list of nodes
        mf_prob->G_nodes.push_back(new_node);
    }

    //Every block should be in the node_map
    assert(node_map.size() == g_blocklist.size());

    /*
     *  Convert nets
     */
    for(t_net_map::iterator net_iter = g_netlist.begin(); net_iter != g_netlist.end(); net_iter++) {
        t_net* net = net_iter->second;

        //Two pin nets only
        assert(net->blocks.size() == 2);

        t_block* start_blk;
        t_block* finish_blk;
        int cnt = 0;
        for(t_block_map::iterator blk_iter = net->blocks.begin(); blk_iter != net->blocks.end(); blk_iter++) {
            if(cnt == 0) {
                start_blk = blk_iter->second;
            } else {
                finish_blk = blk_iter->second;
            }
            cnt++;
        }

        add_edge(mf_prob, node_map, start_blk, finish_blk);
    }
    
    return mf_prob;
}

/*
 *  Adds an edge to the max flow problem if it does not already exit.
 *  If it exists, increments it's capacity by one
 *
 *  Uses node_map to look up the correct mf_nodes for the start_blk and finish_blk
 */
void add_edge(t_max_flow* mf_prob, map<t_block*, t_mf_node*> node_map, t_block* start_blk, t_block* finish_blk) {
    t_mf_edge* mf_edge;  //The edge

    // Get the correct mf_nodes for the given blocks
    map<t_block*, t_mf_node*>::iterator start_node_iter = node_map.find(start_blk);
    assert(start_node_iter != node_map.end());

    map<t_block*, t_mf_node*>::iterator finish_node_iter = node_map.find(finish_blk);
    assert(finish_node_iter != node_map.end());

    t_mf_node* start_node = start_node_iter->second;
    t_mf_node* finish_node = finish_node_iter->second;

    //Since we collapse the left and right partitions, we may end up with self-loops
    //  on those nodes.  Do not create them.
    if(start_node == finish_node) return;

    /*
     *  First find if such an edge already exists
     */
    bool found_edge = false;
    //Check the edges on the start node for any connections to the finish node
    for(t_mf_edge_vec::iterator edge_iter = start_node->G_edges.begin(); edge_iter != start_node->G_edges.end(); edge_iter++) {
        t_mf_edge* search_edge = *edge_iter;

        //At most two pins per net
        assert(search_edge->nodes.size() == 2);

        t_mf_node* node_A = search_edge->nodes.at(0);
        t_mf_node* node_B = search_edge->nodes.at(1);

        if(node_A == finish_node || node_B == finish_node) {
            found_edge = true;
            mf_edge = search_edge;
            break;
        }
    }

    /*
     *  If no edge exists create a new one
     */
    if(!found_edge) {
        mf_edge = new t_mf_edge;

        //Init
        mf_edge->pos_capacity = 0;
        mf_edge->pos_flow = 0;
        mf_edge->neg_capacity = 0;
        mf_edge->neg_flow = 0;
        mf_edge->nodes.push_back(start_node);
        mf_edge->nodes.push_back(finish_node);

        //Add to the problem
        mf_prob->G_edges.push_back(mf_edge);

        //Add to the nodes
        start_node->G_edges.push_back(mf_edge);
        finish_node->G_edges.push_back(mf_edge);
    }

    /*
     *  Increment the edge capacity by 1
     */
    mf_edge->pos_capacity++;

    return;
}
    
t_max_flow* convert_min_free_block_cut_subproblem_to_max_flow(t_bbnode* subproblem, t_block* source, t_block* sink) {
    t_max_flow* mf_prob = new t_max_flow;
    map<t_block*, t_mf_node*> node_map;

    //Convert each free block
    for(t_block_map::iterator blk_iter = subproblem->free_blocks.begin(); blk_iter != subproblem->free_blocks.end(); blk_iter++) {
        t_block* block = blk_iter->second;

        t_mf_node* new_node = new t_mf_node;
        new_node->type = DEFAULT;
        new_node->index = block->index;
        new_node->traversed = false;

        if(block == source) {
            new_node->type = SOURCE;
            mf_prob->G_source = new_node;
        } else if (block == sink) {
            new_node->type = SINK;
            mf_prob->G_sink = new_node;
        }

        //Map Look up from block->node
        node_map[block] = new_node;

        //Add the node to the list of nodes
        mf_prob->G_nodes.push_back(new_node);
    }

    //Convert each net
    for(t_block_map::iterator blk_iter = subproblem->free_blocks.begin(); blk_iter != subproblem->free_blocks.end(); blk_iter++) {
        t_block* blk = blk_iter->second;
        for(t_net_map::iterator net_iter = blk->nets.begin(); net_iter != blk->nets.end(); net_iter++) {
            t_net* net = net_iter->second;
            
            //Two pin nets only
            assert(net->blocks.size() == 2);
            t_block* block_A;
            t_block* block_B;

            int cnt = 0;
            for(t_block_map::iterator net_blk_iter = net->blocks.begin(); net_blk_iter != net->blocks.end(); net_blk_iter++) {
                if(cnt == 0) {
                    block_A = net_blk_iter->second;
                } else {
                    block_B = net_blk_iter->second;
                }
                cnt++;
            }
            assert(cnt == 2);

            if(subproblem->free_blocks.find(block_A->map_index) == subproblem->free_blocks.end()) continue; //Net goes outside free_blocks
            if(subproblem->free_blocks.find(block_B->map_index) == subproblem->free_blocks.end()) continue; //Net goes outside free_blocks

            //Net is internal to free blocks - convert it
            add_edge(mf_prob, node_map, block_A, block_B);

        }
    }
    return mf_prob;
}

void verify_max_flow_problem(t_max_flow* mf_prob) {
    map<t_mf_edge*, bool> seen_G_edges;
    map<t_mf_edge*, bool> seen_Gf_edges;
    /*
     * Check all nodes
     */
    int G_edges_on_nodes = 0;
    int Gf_edges_on_nodes = 0;
    for(t_mf_node_vec::iterator node_iter = mf_prob->G_nodes.begin(); node_iter != mf_prob->G_nodes.end(); node_iter++) {
        t_mf_node* node = *node_iter;
        assert(node != NULL);

        verify_max_flow_node(node);

        for(t_mf_edge_vec::iterator G_edge_iter = node->G_edges.begin(); G_edge_iter != node->G_edges.end(); G_edge_iter++) {
            t_mf_edge* G_edge = *G_edge_iter;
            if(!seen_G_edges[G_edge]) {
                seen_G_edges[G_edge] = true;
            }
        }
        for(t_mf_edge_vec::iterator Gf_edge_iter = node->Gf_edges.begin(); Gf_edge_iter != node->Gf_edges.end(); Gf_edge_iter++) {
            t_mf_edge* Gf_edge = *Gf_edge_iter;
            if(!seen_Gf_edges[Gf_edge]) {
                seen_Gf_edges[Gf_edge] = true;
            }
        }

        G_edges_on_nodes += node->G_edges.size();
        Gf_edges_on_nodes += node->Gf_edges.size();
    }

    /*
     * Check all edges
     */
    //First the G_edges
    int total_G_edges = mf_prob->G_edges.size();
    int total_Gf_edges = mf_prob->Gf_edges.size();
    for(t_mf_edge_vec::iterator G_edge_iter = mf_prob->G_edges.begin(); G_edge_iter != mf_prob->G_edges.end(); G_edge_iter++) {
        t_mf_edge* G_edge = *G_edge_iter;
        assert(G_edge != NULL);

        if(!seen_G_edges[G_edge]) {
            assert(0);
        }
    }

    //Second the Gf_edges
    for(t_mf_edge_vec::iterator Gf_edge_iter = mf_prob->Gf_edges.begin(); Gf_edge_iter != mf_prob->Gf_edges.end(); Gf_edge_iter++) {
        t_mf_edge* Gf_edge = *Gf_edge_iter;
        assert(Gf_edge != NULL);
        
        if(!seen_Gf_edges[Gf_edge]) {
            assert(0);
        }
    }

    //Two pin nets, so each edge appears twice
    assert(G_edges_on_nodes == 2*total_G_edges);
    assert(Gf_edges_on_nodes == 2*total_Gf_edges);

    //Verify edge self-consistency -> no repeats
    int G_edges_size = mf_prob->G_edges.size();
    for(int i = 0; i < G_edges_size; i++) {
        t_mf_edge* first_edge = mf_prob->G_edges.at(i);
        for(int j = 0; j < G_edges_size; j++) {
            t_mf_edge* second_edge = mf_prob->G_edges.at(j);

            if(i == j) continue; //No point comparing to itself

            //nodes must not be the same, check both ordering cases
            assert( (first_edge->nodes.at(0) != second_edge->nodes.at(0) || first_edge->nodes.at(1) != second_edge->nodes.at(1)) && (first_edge->nodes.at(0) != second_edge->nodes.at(1) || first_edge->nodes.at(1) != second_edge->nodes.at(0)) );

        }
    }
    int Gf_edges_size = mf_prob->Gf_edges.size();
    for(int i = 0; i < Gf_edges_size; i++) {
        t_mf_edge* first_edge = mf_prob->Gf_edges.at(i);
        for(int j = 0; j < Gf_edges_size; j++) {
            t_mf_edge* second_edge = mf_prob->Gf_edges.at(j);

            if(i == j) continue; //No point comparing to itself

            //nodes must not be the same, check both ordering cases
            assert( (first_edge->nodes.at(0) != second_edge->nodes.at(0) || first_edge->nodes.at(1) != second_edge->nodes.at(1)) && (first_edge->nodes.at(0) != second_edge->nodes.at(1) || first_edge->nodes.at(1) != second_edge->nodes.at(0)) );

        }
    }
}

void verify_max_flow_node(t_mf_node* node) {
    assert(node != NULL);
    for(t_mf_edge_vec::iterator G_edge_iter = node->G_edges.begin(); G_edge_iter != node->G_edges.end(); G_edge_iter++) {
        t_mf_edge* G_edge = *G_edge_iter;
        assert(G_edge != NULL);
    }

    //Second the Gf_edges
    for(t_mf_edge_vec::iterator Gf_edge_iter = node->Gf_edges.begin(); Gf_edge_iter != node->Gf_edges.end(); Gf_edge_iter++) {
        t_mf_edge* Gf_edge = *Gf_edge_iter;
        assert(Gf_edge != NULL);
    }
}

void dump_path(t_path* path) {
    printf("\t\t    Path Res. Cap.: %d\n", path->residual_capacity);

    int cnt = 0;
    for(t_mf_edge_vec::iterator edge_iter = path->edges.begin(); edge_iter != path->edges.end(); edge_iter++) {
        t_mf_edge* G_edge = *edge_iter;

        dump_edge(G_edge);
        cnt++;
    }

}

void dump_mf_graph(t_max_flow* mf_prob) {

    printf("\t\t    Max Flow Graph\n");
    for(int i = 0; i < mf_prob->G_nodes.size(); i++) {
        t_mf_node* node = mf_prob->G_nodes.at(i);
        printf("\t\t      Block: %s\n", get_node_name(node).c_str());
    }

    printf("\t\t    G_edges:\n");
    for(int i = 0; i < mf_prob->G_edges.size(); i++) {
        t_mf_edge* edge = mf_prob->G_edges.at(i);
        dump_edge(edge);
    }
    printf("\t\t    Gf_edges:\n");
    for(int i = 0; i < mf_prob->Gf_edges.size(); i++) {
        t_mf_edge* edge = mf_prob->Gf_edges.at(i);
        dump_edge(edge);
    }
}

void dump_edge(t_mf_edge* edge) {
        assert(edge->nodes.size() == 2);
        t_mf_node* nodeA = edge->nodes.at(0);
        t_mf_node* nodeB = edge->nodes.at(1);

        printf("\t\t      Edge: %s <-> %s\n", get_node_name(nodeA).c_str(), get_node_name(nodeB).c_str());

}

std::string get_node_name(t_mf_node* node) {
    std::ostringstream oss;
    if(node->type == DEFAULT) {
        oss << node->index;

    } else if (node->type == SOURCE) {
        oss << "SOURCE";

    } else if (node->type == SINK) {
        oss << "SINK";

    } else {
        //Should never happen
        assert(0);
    }

    if(node->traversed) {
        oss << "(" << node->label << ")";
    }

    return oss.str();
}
