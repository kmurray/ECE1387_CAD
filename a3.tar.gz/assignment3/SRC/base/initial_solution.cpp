//================================================================================================
// INCLUDES 
//================================================================================================
#include <assert.h>
#include <data_structs.h>
#include <util.h>
#include <initial_solution.h>
#include <verify.h>


//================================================================================================
// INTERNAL FUNCTION DECLARTAIONS 
//================================================================================================
t_bbnode* create_initial_solution();
pair<int,t_block*> get_random_block();

//================================================================================================
// INTERNAL FUCTION IMPLIMENTATIONS
//================================================================================================

/*
 * Generate multiple greedy initial solutions from up to 
 * INITIAL_SOLUTION_ITERATIONS random seed blocks. 
 * Keep the best one.
 */
t_bbnode* find_best_initial_solution() {
    printf("Generate intial solutions:\n");
    t_bbnode* best_initial_soln = create_initial_solution();

    int best_initial_soln_cut_cnt = evaluate_solution(best_initial_soln);
    printf("\tFirst initial solution: %d\n", best_initial_soln_cut_cnt);

    for(int i = 0; i < INITIAL_SOLUTION_ITERATIONS - 1; i++) {
        t_bbnode* initial_soln = create_initial_solution();

        int initial_soln_cut_cnt = evaluate_solution(initial_soln);
        if(initial_soln_cut_cnt < best_initial_soln_cut_cnt) {
            best_initial_soln_cut_cnt = initial_soln_cut_cnt;
            best_initial_soln = initial_soln;
            printf("\tImproved initial soln at iter %d to: %d\n", i, best_initial_soln_cut_cnt);
        }
    }

    return best_initial_soln;
}

t_bbnode* create_initial_solution() {

    t_bbnode* initial_soln = new t_bbnode;

    //Start with all the blocks on the free list
    // NOTE: this is copy of g_blocklist not a reference
    initial_soln->free_blocks = g_blocklist;

    //Unitl we have met the even split constraint
    while(initial_soln->left_blocks.size() < g_blocklist.size()/2) {
        pair<int,t_block*> seed_block_pair = get_random_block();
        int index = seed_block_pair.first;
        t_block* seed_block = seed_block_pair.second;

        //Skip if we have already seen this block
        if(initial_soln->left_blocks.find(index) != initial_soln->left_blocks.end()) {
            continue;
        }

        //Put the seed block on the left side
        initial_soln->left_blocks[index] = seed_block;
        //Remove it from the free blocks
        initial_soln->free_blocks.erase(index);

        //Look through the nets attached to the random seed block, and greedily pack blocks connected
        // to them into the same (LEFT) side
        for(t_net_map::iterator net_iter = seed_block->nets.begin(); net_iter != seed_block->nets.end(); net_iter++) {
            t_net* net = net_iter->second;

            //Blocks on this net
            for(t_block_map::iterator block_iter = net->blocks.begin(); block_iter != net->blocks.end(); block_iter++) {

                //Skip this block if it is already in the left list
                if(initial_soln->left_blocks.find(block_iter->first) != initial_soln->left_blocks.end()) {
                    continue;
                }

                if(initial_soln->left_blocks.size() + 1 <= g_blocklist.size()/2) {
                    //Add the item, since we aren't at the half-way point yet
                    add_block_from_freelist(block_iter->first, LEFT, initial_soln);

                } else {
                    //At the halfway point, don't add any more
                    break;
                }
            }
            if(initial_soln->left_blocks.size() >= g_blocklist.size()/2) {
                //At the halfway point, don't add any more
                break;
            }
        }
    }

    //Move all the remaining blocks to the right, and empty the free list
    initial_soln->right_blocks = initial_soln->free_blocks;
    initial_soln->free_blocks.erase(initial_soln->free_blocks.begin(), initial_soln->free_blocks.end());

    assert(initial_soln->free_blocks.size() == 0);
    assert(initial_soln->left_blocks.size() == initial_soln->right_blocks.size());
    assert(initial_soln->left_blocks.size() == g_blocklist.size()/2);

    verify_subproblem(initial_soln);
    
    return initial_soln;
}

pair<int,t_block*> get_random_block() {
    //Generate a random index in range
    int index = rand_in_range(g_blocklist.size());

    t_block_map::iterator rand_block_iter = g_blocklist.find(index);
    while(rand_block_iter == g_blocklist.end()) {
        printf("Warning: found non-sequential block index: %d\n", index);
        index = rand_in_range(g_blocklist.size());
        rand_block_iter = g_blocklist.find(index);
    }
    return pair<int,t_block*>(index,rand_block_iter->second);

}

void add_block_from_freelist(int block_index, t_side side, t_bbnode* bbnode) {
    //The block must be in the freelist
    t_block_map::iterator block_iter = bbnode->free_blocks.find(block_index);
    assert(block_iter != bbnode->free_blocks.end());

    //Add the block to the appropriate side
    pair<t_block_map::iterator, bool> ret;
    if(side == LEFT) {
        ret = bbnode->left_blocks.insert( t_block_pair(block_index, block_iter->second) );
        //Update the max value
        if(bbnode->max_left_index < block_index) {
            bbnode->max_left_index = block_index;
        }
    } else { //RIGHT
        ret = bbnode->right_blocks.insert( t_block_pair(block_index, block_iter->second) );
        //Update the max value
        if(bbnode->max_right_index < block_index) {
            bbnode->max_right_index = block_index;
        }
    }
    //Fail if something was overwritten
    assert(ret.second != false);

    //Remove the block from the freelist
    bbnode->free_blocks.erase(block_index);

}

