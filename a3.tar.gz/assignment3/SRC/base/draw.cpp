#include <data_structs.h>
#include <util.h>
#include <draw.h>
#include <argparse.h>

//=============================================================================
// Global Vars
//=============================================================================
float world_dim_x, world_dim_y;
float vert_grid;

extern t_CHIP* g_CHIP;
extern t_arguments* g_args;

//=============================================================================
// Local Function Declarations
//=============================================================================
void draw_search_tree(t_bbnode* node, int level, float parent_x, float start_x, float end_x, int num_siblings, int sibling_num);
double vert_position(int level);
void draw_tree_level_names(int num_levels);


//=============================================================================
// Function Implimentations
//=============================================================================
void start_interactive_graphics(void) {
    if(g_args->no_disp) return;
    world_dim_x = 150;
    world_dim_y = 100;

    init_world(-1*world_dim_x*WORLD_DIM_SCALE, world_dim_y*(1 + WORLD_DIM_SCALE), world_dim_x*(1 + WORLD_DIM_SCALE), -1*world_dim_y*WORLD_DIM_SCALE);
    update_message(g_args->netlist_file);

    draw_screen();
    event_loop(button_press, draw_screen);
}

void draw_screen(void) {
    if(g_args->no_disp) return;

    clearscreen();
    
    //World limits
    drawline(0.,0.,world_dim_x,0.); //Bottom
    drawline(0.,0.,0.,world_dim_y); //Left
    drawline(0.,world_dim_y,world_dim_x,world_dim_y); //Top
    drawline(world_dim_x,0.,world_dim_x,world_dim_y); //Right

    //Draw stuff
    int num_levels;
    if(g_args->tree_type == BINARY) {
        num_levels = g_blocklist.size();
    } else {
        num_levels = (int) g_blocklist.size()/2;
    }
    
    //num_levels + 2 to give spacing above and below
    vert_grid = world_dim_y / (num_levels + 1);

    draw_tree_level_names(num_levels);

    draw_search_tree(g_search_root, 1, world_dim_x/2, 0., world_dim_x, 1, 1);

    flushinput();
}

void draw_search_tree(t_bbnode* node, int level, float parent_x, float start_x, float end_x, int num_siblings, int sibling_num) {
    double node_y = vert_position(level);
    double node_x;

    //printf("BBNODE, level: %d, sibling: %d/%d\n", level, sibling_num, num_siblings);

    node_x = start_x + (end_x - start_x)/2;

    fillrect(node_x - BOX_LEN/2, node_y - BOX_LEN/2, node_x + BOX_LEN/2, node_y + BOX_LEN/2);
    char buf[50];

    if(g_args->tree_type != BINARY) {
        snprintf(buf, sizeof(buf), "%d (%d)", node->max_left_index, node->LB);
    } else {
        snprintf(buf, sizeof(buf), "%d (%d)", node->LB, node->UB);
    }

    if(node->status == UNBOUNDED) {
        snprintf(buf, sizeof(buf), "");
    }

    if(node->status == NORMAL) {
        setcolor(BLACK);
    } else if (node->status == PRUNED_BOUND) {
        setcolor(RED);
    } else if (node->status == PRUNED_BALANCE) {
        setcolor(DARKGREY);
        snprintf(buf, sizeof(buf), "B");
    } else if (node->status == OLD_BEST) {
        setcolor(BLUE);
    } else if (node->status == BEST) {
        setcolor(DARKGREEN);
    }
    drawtext(node_x - BOX_LEN, node_y, buf, 50);
    setcolor(BLACK);


    if(level != 1) {
        drawline(node_x, node_y, parent_x, vert_position(level - 1));
        /*
         *if(level < 3) {
         *    drawline(node_x, node_y, parent_x, vert_position(level - 1));
         *} else if (sibling_num == 1 || sibling_num == num_siblings) {
         *    drawline(node_x, node_y, parent_x, vert_position(level - 1));
         *}
         */
    }


    float child_spacing;
    if(g_args->tree_type == BINARY) {
        child_spacing = (end_x - start_x) / node->children.size();
    } else {
        child_spacing = (end_x - start_x) / 2;
    }
    float child_start_x = start_x;
    float child_end_x = child_start_x + child_spacing;

    int child_index = 1;
    for(t_bbnode_map::iterator node_iter = node->children.begin(); node_iter != node->children.end(); node_iter++) {
        t_bbnode* child_node = node_iter->second;

        //printf("\tLevel: %d sibling: %d/%d, Child: %d, Block#: %d\n", level, sibling_num, num_siblings, child_index, block_index);
        draw_search_tree(child_node, level+1, node_x, child_start_x, child_end_x, node->children.size(), child_index);

        if(g_args->tree_type != BINARY) {
            child_spacing /= 2;
        }
        child_start_x = child_end_x;
        child_end_x += child_spacing;
        child_index++;
    }
}

double vert_position(int level) {
    float offset = 0.;
    if(g_args->tree_type == BINARY) {
        offset = 0.5*vert_grid;
    }
    return world_dim_y - level*vert_grid + offset;
}

void draw_tree_level_names(int num_levels) {
    int horiz_pos = 0 - (WORLD_DIM_SCALE/2)*world_dim_x;
    int i = 1;
    //for(int i = 1; i <= num_levels; i++) {
    for(t_block_map::iterator blk_iter = g_blocklist.begin(); blk_iter != g_blocklist.end(); blk_iter++) {
        t_block* block = blk_iter->second;
        int vert_pos = vert_position(i);

        float offset = 0.;
        if(g_args->tree_type == BINARY) {
            offset = 0.5*vert_grid;
        }
        char buf[50];
        if(g_args->tree_type == BINARY) {
            snprintf(buf, sizeof(buf), "B%d", block->index);
        } else {
            snprintf(buf, sizeof(buf), "S%d", block->index);
        }
        drawtext(horiz_pos, vert_pos - offset, buf, 50);

        i++;
    }
}

void button_press (float x, float y) {
    /* Called whenever event_loop gets a button press in the graphics *
     * area.  Allows the user to do whatever he/she wants with button *
     * clicks.                                                        */

     printf("User clicked at coordinates (%.2f, %.2f)\n", x, y);
}

